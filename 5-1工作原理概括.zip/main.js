import show from './show';
show('Webpack');
